from flask import Flask

def create_app():
    app = Flask(__name__, template_folder='views', static_folder='static')

    app.config['SECRET_KEY'] = 'uma_chave_secreta'
    from app.controllers.task_controller import task_bp
    app.register_blueprint(task_bp)
    return app