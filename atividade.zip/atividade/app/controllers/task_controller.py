from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.models.task_model import Task

task_bp = Blueprint('tasks', __name__)

@task_bp.route('/')
def list_tasks():
    tasks = Task.find_all()
    return render_template('tasks.html', tasks=tasks)

@task_bp.route('/add', methods=['POST'])
def add_task():
    title = request.form.get('title')
    if title:
        new_task = Task(title=title)
        new_task.save()
        flash('Tarefa adicionada com sucesso!', 'success')
    else:
        flash('O título da tarefa não pode ser vazio!', 'danger')
    return redirect(url_for('tasks.list_tasks'))

@task_bp.route('/toggle/<int:task_id>')
def toggle_status(task_id):
    task = Task.find_by_id(task_id)
    if task:
        task.status = 'Concluída' if task.status == 'Pendente' else 'Pendente'
        task.save()
    return redirect(url_for('tasks.list_tasks'))

@task_bp.route('/delete/<int:task_id>')
def delete_task(task_id):
    task = Task.find_by_id(task_id)
    if task:
        task.delete()
        flash('Tarefa removida!', 'info')
    return redirect(url_for('tasks.list_tasks'))