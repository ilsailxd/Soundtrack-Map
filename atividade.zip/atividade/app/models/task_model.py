
from app.db import Database

class Task:
    def __init__(self, title, status='Pendente', id=None):
        self.id = id
        self.title = title
        self.status = status

    def save(self):
        """Salva uma nova tarefa ou atualiza uma existente"""
        with Database() as conn:
            cursor = conn.cursor()
            if self.id is None:
                query = "INSERT INTO tasks (title, status) VALUES (?, ?)"
                cursor.execute(query, (self.title, self.status))
                self.id = cursor.lastrowid
            else:
                query = "UPDATE tasks SET title = ?, status = ? WHERE id = ?"
                cursor.execute(query, (self.title, self.status, self.id))
        return self

    def delete(self):
        """Remove a tarefa do banco de dados"""
        if self.id:
            with Database() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM tasks WHERE id = ?", (self.id,))
    @classmethod
    def _create_from_row(cls, row):
        if not row:
            return None
        return cls(
            id=row['id'],
            title=row['title'],
            status=row['status']
        )

    @classmethod
    def find_all(cls):
        """Retorna todas as tarefas"""
        with Database() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tasks ORDER BY id DESC")
            rows = cursor.fetchall()
            return [cls._create_from_row(row) for row in rows]

    @classmethod
    def find_by_id(cls, task_id):
        """Busca uma tarefa específica pelo ID"""
        with Database() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
            row = cursor.fetchone()
            return cls._create_from_row(row)