from contextlib import contextmanager
import os
import sqlite3

DATABASE_NAME = 'soundtrack_map.db'


@contextmanager
def get_db_connection():
  conn = sqlite3.connect(DATABASE_NAME)
  conn.row_factory = sqlite3.Row  # Mantém o acesso por nome da coluna!
  try:
    yield conn
    conn.commit()  # Salva automaticamente ao final do bloco 'with'
  except Exception as e:
    conn.rollback()  # Desfaz se der erro no meio do caminho
    raise e
  finally:
    conn.close()  # Fecha automaticamente ao sair do bloco 'with'


def init_db():
  # Olha como o próprio init_db já fica mais limpo sem commit() e close() no final:
  with get_db_connection() as conn:
    cursor = conn.cursor()

    # Tabela de Usuários
    cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """)

    # Tabela de Trilha Sonora
    cursor.execute("""
            CREATE TABLE IF NOT EXISTS soundtracks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                artist TEXT NOT NULL,
                music_url TEXT NOT NULL,
                image_url TEXT,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                user_id INTEGER,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)