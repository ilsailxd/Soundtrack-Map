from app.db import get_db_connection

with get_db_connection() as conn:
  users = conn.execute('SELECT * FROM users').fetchall()
# Saiu da indentação? O Python já deu commit e fechou a conexão!

class UserModel:
    @staticmethod
    def create_user(username, password):
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            conn.commit()
            return True
        except:
            return False
        finally:
            conn.close()

    @staticmethod
    def get_by_username(username):
        conn = get_db_connection()
        cursor = conn.cursor()
        user = cursor.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        return user