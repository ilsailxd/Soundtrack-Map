from app.db import get_db_connection

class SoundtrackModel:
    @staticmethod
    def get_all():
        conn = get_db_connection()
        cursor = conn.cursor()
        data = cursor.execute('SELECT * FROM soundtracks').fetchall()
        conn.close()
        # Converte as linhas do banco sqlite3.Row em dicionários
        return [dict(row) for row in data]

    @staticmethod
    def create(title, artist, music_url, image_url, latitude, longitude, user_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO soundtracks (title, artist, music_url, image_url, latitude, longitude, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (title, artist, music_url, image_url, latitude, longitude, user_id))
        conn.commit()
        conn.close()