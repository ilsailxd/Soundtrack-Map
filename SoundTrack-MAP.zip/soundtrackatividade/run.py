
import os
from app import create_app

app = create_app()

if __name__ == '__main__':
    debug_mode = os.environ.get('FLASK_DEBUG', 'true').lower() == 'true'

    app.run(
        debug=debug_mode,
        port=5000
    )
