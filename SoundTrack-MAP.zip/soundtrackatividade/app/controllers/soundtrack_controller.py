
import os
import uuid

from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    session,
    current_app,
    abort,
    flash
)

from werkzeug.utils import secure_filename

from app.models.soundtrack_model import SoundtrackModel
from app.middleware import login_required


soundtrack_bp = Blueprint('soundtrack', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}


# ==========================================
# FUNÇÕES AUXILIARES
# ==========================================

def save_uploaded_image(file):
    filename = secure_filename(file.filename)

    if not filename:
        raise ValueError('Nome de arquivo inválido.')

    extension = filename.rsplit('.', 1)[-1].lower()

    if '.' not in filename or extension not in ALLOWED_EXTENSIONS:
        raise ValueError('Formato de imagem não permitido.')

    # Nome único para evitar sobrescrita
    unique_filename = f'{uuid.uuid4().hex}.{extension}'

    upload_path = os.path.join(
        current_app.config['UPLOAD_FOLDER'],
        unique_filename
    )

    file.save(upload_path)

    return url_for(
        'static',
        filename=f'img/{unique_filename}'
    )


def get_coordinates():
    try:
        latitude = float(request.form.get('latitude', ''))
        longitude = float(request.form.get('longitude', ''))
    except (ValueError, TypeError):
        abort(400)

    if not (-90 <= latitude <= 90):
        abort(400)

    if not (-180 <= longitude <= 180):
        abort(400)

    return latitude, longitude


# ==========================================
# MAPA PRINCIPAL
# ==========================================

@soundtrack_bp.route('/')
@login_required
def dashboard():

    soundtracks = SoundtrackModel.get_all()

    return render_template(
        'dashboard.html',
        soundtracks=soundtracks,
        user_id=session['user_id']
    )


# ==========================================
# ADICIONAR MEMÓRIA
# ==========================================

@soundtrack_bp.route('/adicionar', methods=['GET', 'POST'])
@login_required
def adicionar():

    if request.method == 'POST':

        title = request.form.get('title', '').strip()
        artist = request.form.get('artist', '').strip()
        music_url = request.form.get('music_url', '').strip()

        latitude, longitude = get_coordinates()

        place_name = request.form.get('place_name', '').strip()
        description = request.form.get('description', '').strip()

        image_url = request.form.get(
            'image_url_input', ''
        ).strip()

        file = request.files.get('image_file')

        if file and file.filename:
            try:
                image_url = save_uploaded_image(file)
            except ValueError as error:
                flash(str(error), 'error')
                return redirect(url_for('soundtrack.adicionar'))

        SoundtrackModel.create(
            title,
            artist,
            music_url,
            image_url,
            latitude,
            longitude,
            session['user_id'],
            place_name,
            description
        )

        flash('Memória adicionada com sucesso!', 'success')

        return redirect(url_for('soundtrack.dashboard'))

    return render_template('adicionar.html')


# ==========================================
# EDITAR MEMÓRIA
# ==========================================

@soundtrack_bp.route(
    '/editar/<int:soundtrack_id>',
    methods=['GET', 'POST']
)
@login_required
def editar(soundtrack_id):

    memory = SoundtrackModel.get_by_id(soundtrack_id)

    # Verifica se a memória existe e pertence ao usuário
    if not memory or memory['user_id'] != session['user_id']:
        abort(404)

    if request.method == 'POST':

        title = request.form.get('title', '').strip()
        artist = request.form.get('artist', '').strip()
        music_url = request.form.get('music_url', '').strip()

        latitude, longitude = get_coordinates()

        place_name = request.form.get('place_name', '').strip()
        description = request.form.get('description', '').strip()

        # Mantém a imagem anterior
        image_url = memory['image_url']

        file = request.files.get('image_file')

        if file and file.filename:
            try:
                image_url = save_uploaded_image(file)
            except ValueError as error:
                flash(str(error), 'error')
                return redirect(
                    url_for('soundtrack.editar', soundtrack_id=soundtrack_id)
                )

        else:
            new_image_url = request.form.get(
                'image_url_input', ''
            ).strip()

            if new_image_url:
                image_url = new_image_url

        SoundtrackModel.update(
            soundtrack_id,
            session['user_id'],
            title,
            artist,
            music_url,
            image_url,
            latitude,
            longitude,
            place_name,
            description
        )

        flash('Memória atualizada com sucesso!', 'success')

        return redirect(url_for('soundtrack.dashboard'))

    return render_template(
        'adicionar.html',
        memory=memory
    )


# ==========================================
# EXCLUIR MEMÓRIA
# ==========================================

@soundtrack_bp.route(
    '/excluir/<int:soundtrack_id>',
    methods=['POST']
)
@login_required
def excluir(soundtrack_id):

    deleted = SoundtrackModel.delete(
        soundtrack_id,
        session['user_id']
    )

    if not deleted:
        abort(404)

    flash('Memória excluída com sucesso!', 'success')

    return redirect(url_for('soundtrack.dashboard'))
