
from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash
)

from app.models.user_model import UserModel


auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':

        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        # Validação dos campos.
        if not username or not password:
            flash('Preencha todos os campos.', 'error')
            return render_template('register.html')

        if len(username) < 3:
            flash('O usuário precisa ter pelo menos 3 caracteres.', 'error')
            return render_template('register.html')

        if len(password) < 8:
            flash('A senha precisa ter pelo menos 8 caracteres.', 'error')
            return render_template('register.html')

        # Criação da conta.
        if UserModel.create_user(username, password):

            flash('Conta criada com sucesso! Faça login.', 'success')
            return redirect(url_for('auth.login'))

        flash('Esse nome de usuário já está cadastrado.', 'error')

    return render_template('register.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        if not username or not password:
            flash('Informe seu usuário e sua senha.', 'error')
            return render_template('login.html')

        user = UserModel.get_by_username(username)

        if user and UserModel.verify_password(user, password):

            # Limpa os dados anteriores da sessão.
            session.clear()

            # Salva os dados do usuário autenticado.
            session['user_id'] = user['id']
            session['username'] = user['username']

            return redirect(url_for('soundtrack.dashboard'))

        flash('Usuário ou senha inválidos.', 'error')

    return render_template('login.html')


@auth_bp.route('/logout')
def logout():

    session.clear()

    flash('Você saiu da sua conta.', 'success')

    return redirect(url_for('auth.login'))
