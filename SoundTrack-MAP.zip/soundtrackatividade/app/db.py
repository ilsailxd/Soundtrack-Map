
import os
import sqlite3
from contextlib import AbstractContextManager

# Caminho absoluto do banco de dados.
# O arquivo ficará na mesma pasta de run.py.
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_NAME = os.path.join(BASE_DIR, 'soundtrack_map.db')


class DatabaseConnection(AbstractContextManager):

    def __enter__(self):
        self.conn = sqlite3.connect(DATABASE_NAME)
        self.conn.row_factory = sqlite3.Row

        # Ativa a verificação das chaves estrangeiras.
        self.conn.execute('PRAGMA foreign_keys = ON')

        self.cursor = self.conn.cursor()
        return self.cursor

    def __exit__(self, exc_type, exc_value, traceback):

        try:
            if exc_type is None:
                self.conn.commit()
            else:
                self.conn.rollback()

        finally:
            self.cursor.close()
            self.conn.close()

        return False


def get_db():
    return DatabaseConnection()


def init_db():

    with get_db() as cursor:

        # Tabela de usuários
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')

        # Tabela de memórias musicais
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS soundtracks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                artist TEXT NOT NULL,
                music_url TEXT NOT NULL,
                image_url TEXT,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                user_id INTEGER,
                place_name TEXT DEFAULT '',
                description TEXT DEFAULT '',

                FOREIGN KEY (user_id)
                REFERENCES users(id)
                ON DELETE CASCADE
            )
        ''')

        # Verifica se as novas colunas já existem.
        cursor.execute("PRAGMA table_info(soundtracks)")
        columns = [column['name'] for column in cursor.fetchall()]

        # Migração: adiciona as colunas sem apagar os registros antigos.
        if 'place_name' not in columns:
            cursor.execute('''
                ALTER TABLE soundtracks
                ADD COLUMN place_name TEXT DEFAULT ''
            ''')

        if 'description' not in columns:
            cursor.execute('''
                ALTER TABLE soundtracks
                ADD COLUMN description TEXT DEFAULT ''
            ''')

        # Índice para facilitar buscas pelas publicações de cada usuário.
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_soundtracks_user
            ON soundtracks(user_id)
        ''')
