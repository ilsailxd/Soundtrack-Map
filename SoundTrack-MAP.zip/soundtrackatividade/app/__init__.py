
import os
from flask import Flask, render_template
from app.db import init_db
from flask_wtf.csrf import CSRFProtect


def create_app():
    app = Flask(__name__, template_folder='views', static_folder='static')

    # Configurações de segurança
    app.config['SECRET_KEY'] = os.environ.get(
        'SECRET_KEY',
        'soundtrack-map-chave-local-desenvolvimento'
    )
    csrf = CSRFProtect(app)

    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['SESSION_COOKIE_SECURE'] = (
        os.environ.get('SESSION_COOKIE_SECURE', '').lower() == 'true'
    )

    # Limite de upload: 5 MB
    app.config['MAX_CONTENT_LENGTH'] = 15 * 1024 * 1024

    # Pasta de upload de imagens
    upload_folder = os.path.join(app.static_folder, 'img')
    os.makedirs(upload_folder, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = upload_folder

    # Inicializar banco SQLite
    init_db()

    # Registrar controllers
    from app.controllers.auth_controller import auth_bp
    from app.controllers.soundtrack_controller import soundtrack_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(soundtrack_bp)

    # Página para endereço não encontrado
    @app.errorhandler(404)
    def page_not_found(error):
        return render_template('404.html'), 404

    # Página para erro interno
    @app.errorhandler(500)
    def internal_server_error(error):
        app.logger.error('Erro interno no servidor: %s', error)
        return 'Ocorreu um erro interno. Tente novamente mais tarde.', 500

    return app
