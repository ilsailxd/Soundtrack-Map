
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

from app.db import get_db


class UserModel:

    @staticmethod
    def create_user(username, password):

        password_hash = generate_password_hash(password)

        try:
            with get_db() as cursor:
                cursor.execute('''
                    INSERT INTO users (username, password)
                    VALUES (?, ?)
                ''', (username, password_hash))

            return True

        except sqlite3.IntegrityError:
            return False

    @staticmethod
    def get_by_username(username):

        with get_db() as cursor:
            cursor.execute('''
                SELECT *
                FROM users
                WHERE username = ?
            ''', (username,))

            user = cursor.fetchone()
            return dict(user) if user else None

    @staticmethod
    def get_by_id(user_id):

        with get_db() as cursor:
            cursor.execute('''
                SELECT id, username
                FROM users
                WHERE id = ?
            ''', (user_id,))

            user = cursor.fetchone()
            return dict(user) if user else None

    @staticmethod
    def verify_password(user, password):

        stored_password = user['password']

        # Verifica se a senha já está armazenada como hash.
        if stored_password.startswith(('scrypt:', 'pbkdf2:')):
            try:
                return check_password_hash(stored_password, password)
            except ValueError:
                return False

        # Compatibilidade com contas antigas que armazenavam
        # a senha em texto puro.
        if stored_password == password:

            # Atualiza a senha antiga para hash.
            new_hash = generate_password_hash(password)

            with get_db() as cursor:
                cursor.execute('''
                    UPDATE users
                    SET password = ?
                    WHERE id = ?
                ''', (new_hash, user['id']))

            return True

        return False
