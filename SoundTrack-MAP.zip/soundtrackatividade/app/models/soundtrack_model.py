
from app.db import get_db


class SoundtrackModel:

    @staticmethod
    def get_all():

        with get_db() as cursor:
            cursor.execute('''
                SELECT
                    soundtracks.*,
                    users.username
                FROM soundtracks
                LEFT JOIN users
                    ON soundtracks.user_id = users.id
                ORDER BY soundtracks.id DESC
            ''')

            data = cursor.fetchall()
            return [dict(row) for row in data]

    @staticmethod
    def get_by_id(soundtrack_id):

        with get_db() as cursor:
            cursor.execute('''
                SELECT *
                FROM soundtracks
                WHERE id = ?
            ''', (soundtrack_id,))

            data = cursor.fetchone()
            return dict(data) if data else None

    @staticmethod
    def get_by_user(user_id):

        with get_db() as cursor:
            cursor.execute('''
                SELECT *
                FROM soundtracks
                WHERE user_id = ?
                ORDER BY id DESC
            ''', (user_id,))

            data = cursor.fetchall()
            return [dict(row) for row in data]

    @staticmethod
    def create(
        title,
        artist,
        music_url,
        image_url,
        latitude,
        longitude,
        user_id,
        place_name='',
        description=''
    ):

        with get_db() as cursor:
            cursor.execute('''
                INSERT INTO soundtracks (
                    title,
                    artist,
                    music_url,
                    image_url,
                    latitude,
                    longitude,
                    user_id,
                    place_name,
                    description
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                title,
                artist,
                music_url,
                image_url,
                latitude,
                longitude,
                user_id,
                place_name,
                description
            ))

            return cursor.lastrowid

    @staticmethod
    def update(
        soundtrack_id,
        user_id,
        title,
        artist,
        music_url,
        image_url,
        latitude,
        longitude,
        place_name,
        description
    ):

        with get_db() as cursor:
            cursor.execute('''
                UPDATE soundtracks
                SET
                    title = ?,
                    artist = ?,
                    music_url = ?,
                    image_url = ?,
                    latitude = ?,
                    longitude = ?,
                    place_name = ?,
                    description = ?
                WHERE id = ? AND user_id = ?
            ''', (
                title,
                artist,
                music_url,
                image_url,
                latitude,
                longitude,
                place_name,
                description,
                soundtrack_id,
                user_id
            ))

            return cursor.rowcount > 0

    @staticmethod
    def delete(soundtrack_id, user_id):

        with get_db() as cursor:
            cursor.execute('''
                DELETE FROM soundtracks
                WHERE id = ? AND user_id = ?
            ''', (soundtrack_id, user_id))

            return cursor.rowcount > 0
