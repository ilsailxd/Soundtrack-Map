import os
from flask import Flask
from app.db import init_db

def create_app():
    app = Flask(__name__, template_folder='views', static_folder='static')
    app.secret_key = 'soundtrack_map_secret_key'
    
    # Configuração da pasta de upload de imagens
    upload_folder = os.path.join(app.static_folder, 'img')
    os.makedirs(upload_folder, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = upload_folder

    # Inicializar banco SQLite
    init_db()

    # Registrar Controllers / Blueprints
    from app.controllers.auth_controller import auth_bp
    from app.controllers.soundtrack_controller import soundtrack_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(soundtrack_bp)

    return app