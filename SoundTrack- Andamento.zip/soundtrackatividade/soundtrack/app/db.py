import sqlite3
from contextlib import contextmanager

DATABASE_NAME = 'soundtrack_map.db'

def init_db():
    # Cria as tabelas utilizando a função auxiliar de conexão
    with get_db() as cursor:
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS soundtracks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                artist TEXT NOT NULL,
                music_url TEXT NOT NULL,
                image_url TEXT,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                user_id INTEGER,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')

@contextmanager
def get_db():
    conn = sqlite3.connect(DATABASE_NAME)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        yield cursor
        conn.commit()  # Salva (commit) automaticamente se der tudo certo
    except Exception as e:
        conn.rollback()  # Desfaz se houver algum erro
        raise e
    finally:
        conn.close()   # Garante que a conexão será fechada no final