from app.db import get_db

class SoundtrackModel:
    @staticmethod
    def get_all():
        with get_db() as cursor:
            data = cursor.execute('SELECT * FROM soundtracks').fetchall()
            return [dict(row) for row in data]

    @staticmethod
    def create(title, artist, music_url, image_url, latitude, longitude, user_id):
        with get_db() as cursor:
            cursor.execute('''
                INSERT INTO soundtracks (title, artist, music_url, image_url, latitude, longitude, user_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (title, artist, music_url, image_url, latitude, longitude, user_id))