from app.db import get_db

class UserModel:
    @staticmethod
    def create_user(username, password):
        try:
            with get_db() as cursor:
                cursor.execute(
                    'INSERT INTO users (username, password) VALUES (?, ?)',
                    (username, password)
                )
            return True
        except Exception:
            return False

    @staticmethod
    def get_by_username(username):
        with get_db() as cursor:
            cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
            return cursor.fetchone()