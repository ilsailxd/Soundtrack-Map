import os
from flask import Blueprint, render_template, request, redirect, url_for, session, current_app
from werkzeug.utils import secure_filename
from app.models.soundtrack_model import SoundtrackModel
from app.middleware import login_required

soundtrack_bp = Blueprint('soundtrack', __name__)

@soundtrack_bp.route('/')
@login_required #
def dashboard():
    soundtracks = SoundtrackModel.get_all()
    return render_template('dashboard.html', soundtracks=soundtracks)

@soundtrack_bp.route('/adicionar', methods=['GET', 'POST'])
@login_required
def adicionar():
    if request.method == 'POST':
        title = request.form['title']
        artist = request.form['artist']
        music_url = request.form['music_url']
        latitude = float(request.form['latitude'])
        longitude = float(request.form['longitude'])
        
        # Tratamento da Imagem (Upload ou URL)
        image_url = ""
        file = request.files.get('image_file')
        
        if file and file.filename != '':
            filename = secure_filename(file.filename)
            file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
            image_url = url_for('static', filename=f'img/{filename}')
        else:
            image_url = request.form.get('image_url_input', '')

        SoundtrackModel.create(title, artist, music_url, image_url, latitude, longitude, session['user_id'])
        return redirect(url_for('soundtrack.dashboard'))

    return render_template('adicionar.html')